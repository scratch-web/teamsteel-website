/* Team Steel shared behaviour. Load in <head> (no defer) so the theme is applied before first paint. */
(function () {
  'use strict';
  var root = document.documentElement;
  var KEY = 'ts-theme';

  /* ---------- Theme: dark by default, remembered after the user picks ---------- */
  function readTheme() {
    try { var t = localStorage.getItem(KEY); if (t === 'light' || t === 'dark') return t; } catch (e) {}
    return 'dark';
  }
  function applyTheme(t) {
    root.setAttribute('data-theme', t);
    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', t === 'dark' ? '#0b1721' : '#f5f7f6');
    var btn = document.getElementById('theme-toggle');
    if (btn) {
      var label = t === 'dark' ? btn.getAttribute('data-label-to-light') : btn.getAttribute('data-label-to-dark');
      if (label) { btn.setAttribute('aria-label', label); btn.setAttribute('title', label); }
    }
  }
  root.classList.add('js');
  applyTheme(readTheme());

  document.addEventListener('DOMContentLoaded', function () {
    applyTheme(readTheme());
    var reduceMotion = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* Theme toggle */
    var tbtn = document.getElementById('theme-toggle');
    if (tbtn) tbtn.addEventListener('click', function () {
      var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      try { localStorage.setItem(KEY, next); } catch (e) {}
      applyTheme(next);
    });
    window.addEventListener('storage', function (e) { if (e.key === KEY) applyTheme(readTheme()); });

    /* Mobile sidebar drawer */
    var sidebar = document.getElementById('sidebar');
    var scrim = document.getElementById('scrim');
    var menuBtn = document.getElementById('menu-btn');
    var closeBtn = document.getElementById('sidebar-close');
    var wide = window.matchMedia('(min-width: 960px)');
    function setMenu(open, returnFocus) {
      if (!sidebar || !menuBtn) return;
      sidebar.classList.toggle('open', open);
      if (scrim) scrim.classList.toggle('open', open);
      document.body.classList.toggle('menu-open', open);
      menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (open) { var first = sidebar.querySelector('a'); if (first) setTimeout(function () { first.focus(); }, 60); }
      else if (returnFocus) menuBtn.focus();
    }
    if (menuBtn) menuBtn.addEventListener('click', function () { setMenu(!sidebar.classList.contains('open')); });
    if (closeBtn) closeBtn.addEventListener('click', function () { setMenu(false, true); });
    if (scrim) scrim.addEventListener('click', function () { setMenu(false, true); });
    if (sidebar) sidebar.addEventListener('click', function (e) {
      var a = e.target.closest && e.target.closest('a');
      if (a && !wide.matches) setMenu(false);
    });
    if (wide.addEventListener) wide.addEventListener('change', function () { if (wide.matches) setMenu(false); });

    /* Language dropdown (native <details>, enhanced) */
    var lang = document.querySelector('details.lang');
    if (lang) {
      document.addEventListener('click', function (e) { if (lang.open && !lang.contains(e.target)) lang.open = false; });
      lang.addEventListener('focusout', function (e) { if (lang.open && e.relatedTarget && !lang.contains(e.relatedTarget)) lang.open = false; });
    }
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Escape') return;
      if (lang && lang.open) { lang.open = false; var s = lang.querySelector('summary'); if (s) s.focus(); return; }
      if (sidebar && sidebar.classList.contains('open')) setMenu(false, true);
    });

    /* Reveal on scroll */
    if (!reduceMotion && 'IntersectionObserver' in window) {
      var targets = document.querySelectorAll('.hero>*,.page-index,.notice,.card,.schedule,.family-feedback,.tutorial,.resources,.jump');
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('is-visible'); io.unobserve(en.target); } });
      }, { rootMargin: '0px 0px -6% 0px', threshold: 0.06 });
      targets.forEach(function (el, i) {
        el.classList.add('reveal');
        if (el.matches('.card,.time')) el.style.transitionDelay = (i % 2) * 70 + 'ms';
        io.observe(el);
      });
    }

    /* Progress bar, back-to-top, scroll-spy */
    var bar = document.querySelector('.progress i');
    var top = document.getElementById('to-top');
    var spyLinks = [].slice.call(document.querySelectorAll('.jump a[href^="#"], .page-index nav a[href^="#"]'));
    var spy = spyLinks.map(function (a) { return { a: a, el: document.getElementById(a.getAttribute('href').slice(1)) }; }).filter(function (x) { return x.el; });
    var ticking = false;
    function onScroll() {
      ticking = false;
      var y = window.pageYOffset || root.scrollTop;
      var max = root.scrollHeight - window.innerHeight;
      if (bar) bar.style.transform = 'scaleX(' + (max > 0 ? Math.min(1, y / max) : 0) + ')';
      if (top) top.classList.toggle('show', y > 700);
      if (spy.length) {
        var cur = null;
        spy.forEach(function (x) { if (x.el.getBoundingClientRect().top <= 140) cur = x; });
        spy.forEach(function (x) { if (x === cur) x.a.setAttribute('aria-current', 'location'); else x.a.removeAttribute('aria-current'); });
      }
    }
    window.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
    window.addEventListener('resize', onScroll);
    onScroll();
    if (top) top.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' }); });
  });
})();
